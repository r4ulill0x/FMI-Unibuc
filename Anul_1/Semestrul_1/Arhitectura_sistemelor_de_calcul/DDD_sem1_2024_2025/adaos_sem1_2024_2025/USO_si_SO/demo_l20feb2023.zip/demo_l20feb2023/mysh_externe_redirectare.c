#include<unistd.h>
#include<sys/types.h>
#include<sys/wait.h>
#include<sys/stat.h>
#include<fcntl.h>
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<ctype.h>

char ldc[256], *a[256], *p;
int nc, i, inw;

int main(){
  while(1){
    printf(">>");
    gets(ldc);
    inw = 0; nc = 0;
    for(p = ldc; *p; ++p)
      if(!isspace(*p) && !inw) {inw = 1; a[nc++] = p;}
      else if(isspace(*p) && inw) {inw = 0; *p = '\0';}
    a[nc] = NULL;
    if(nc == 0) continue;
    if(!strcmp(a[0],"exit")){
      exit(0);
    }else if(fork()){
            wait(NULL);
          }else{
            int d, s, i, j;
            for(i = 1; i < nc - 1; ++i) {
              if(!strcmp(a[i], ">")) {
                d = open(a[i+1], O_WRONLY | O_CREAT | O_TRUNC, S_IRUSR | S_IWUSR); s = 1;
              } else if(!strcmp(a[i], ">>")) {
                d = open(a[i+1], O_WRONLY | O_CREAT | O_APPEND, S_IRUSR | S_IWUSR); s = 1;
              } else if(!strcmp(a[i], "2>")) {
                d = open(a[i+1], O_WRONLY | O_CREAT | O_TRUNC, S_IRUSR | S_IWUSR); s = 2;
              } else if(!strcmp(a[i], "2>>")) {
                d = open(a[i+1], O_WRONLY | O_CREAT | O_APPEND, S_IRUSR | S_IWUSR); s = 2;
              } else if(!strcmp(a[i], "<")) {
                d = open(a[i+1], O_RDONLY); s = 0;
              } else continue;
              if(d == -1) {perror(a[i]); exit(1);}
              dup2(d, s); close(d);
              for(j = i; j < nc - 1; ++j) a[j] = a[j+2];
              --i; nc -= 2;
            }
            execv(a[0],a);
            perror(a[0]);
            return 1;
          }
  }
  return 0;
}

