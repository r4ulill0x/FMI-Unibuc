#include<unistd.h>
#include<sys/types.h>
#include<sys/wait.h>
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<ctype.h>

char nalias[256][265], valias[256][256], ldc[256], relevant[256], marcaj[256],
     *a[256], *p, *q, buf[256];
int na, nc, i, j, k, stare;

int main(){

  na = 0;
  while(1){
  err:
    printf(">>");
    gets(ldc);

    for(i = 0; i < 256; ++i) marcaj[i] = 1;

    do {

    /* tratare caractere speciale */
    stare = 0; /* 0 = not ignore; 1 = ignore 1; 2 = ignore  unlimited */
    for(i = 0; ldc[i]; ++i)
      switch(stare) {
        case 0: switch(ldc[i]) {
                  case  '"': stare = 1;
                  case '\\': ++stare;
                             bcopy(ldc + (i + 1), ldc + i, strlen(ldc + i));
                             --i;
                             break;
                  default: relevant[i] = 1;
                }
                break;
        case 1: stare = 0;
                relevant[i] = 0;
                break;
        case 2: switch(ldc[i]) {
                  case '"': stare = 0;
                            bcopy(ldc + (i + 1), ldc + i, strlen(ldc + i));
                            --i;
                            break;
                  case '\\': if(ldc[i+1] == '\"' || ldc[i+1] == '\\') {
                               bcopy(ldc + (i + 1), ldc + i, strlen(ldc + i));
                               relevant[i] = 0;
                               break;
                             }
                  default:  relevant[i] = 0;
                }
                break;
      }
    if(stare != 0) {
      fprintf(stderr, "Unterminated command line\n");
      goto err;
    }

    // substitutie alias
    stare = 0; /* 0 = outw; 1 = inw */
    q = p = ldc;
    for(i=0; ldc[i]; ++i)
      if((!isspace(ldc[i]) || !relevant[i]) && !stare) {stare = 1; p = ldc + i;}
      else if(isspace(ldc[i]) && relevant[i] && stare) break;
    stare = 0; q = ldc + i;
    for(i = p - ldc; i < q - ldc; ++i) if(!relevant[i]) break;
    if(i < q - ldc) {
      break;
    } else {
      strncpy(buf, p, q - p); buf[q - p] = '\0';
      for(i = 0; i < na; ++i)
        if(!strcmp(buf, nalias[i]))
          if(marcaj[i])
            if(strlen(ldc) - strlen(buf) + strlen(valias[i]) < 256) {
              bcopy(q, (q - strlen(buf)) + strlen(valias[i]), strlen(q) + 1);
              strncpy(p, valias[i], strlen(valias[i]));
              marcaj[i] = 0;
              stare = 1;
              break;
            } else {
              fprintf(stderr, "Line too long.\n");
              stare = -1;
              break;
            }
          else
            break;
    }

    } while(stare > 0);
    if(stare == -1) continue;

    /* determinare cuvinte */
    stare = 0; /* 0 = outw; 1 = inw */
    nc = 0;
    for(i = 0; ldc[i]; ++i)
      if((!isspace(ldc[i]) || !relevant[i]) && !stare) {stare = 1; a[nc++] = ldc + i;}
      else if(isspace(ldc[i]) && relevant[i] && stare) {stare = 0; ldc[i] = '\0';}
    a[nc] = NULL;
    if(nc == 0) continue;

    /* executare comanda */

    if(!strcmp(a[0],"exit")) exit(0);

    if(!strcmp(a[0],"alias")) {
      if (nc == 1) {
        for(j = 0; j < na; ++j) printf("alias %s='%s'\n", nalias[j], valias[j]);
        continue;
      }
      for(i = 1; i < nc; ++i)
        if (p = strchr(a[i], '=')) {
          strncpy(buf, a[i], p - a[i]); buf[p - a[i]] = '\0';
          for(j = 0; buf[j]; ++j) if(!isalnum(buf[j]) && buf[j] != '_') break;
          if(buf[j]) {
            fprintf(stderr, "Invalid alias name: %s\n", buf);
            continue;
          }
          for(j = 0; j < na; ++j) if(strcmp(buf, nalias[j]) <= 0) break;
          if(j == na || strcmp(buf, nalias[j]) < 0) {
            for(k = na; k > j; --k) {
              strcpy(nalias[k], nalias[k - 1]);
              strcpy(valias[k], valias[k - 1]);
            }
            strcpy(nalias[j], buf); strcpy(valias[j], p + 1);
            ++na;
          } else
            strcpy(valias[j], p + 1);
        } else {
          for(j = 0; j < na; ++j) if(strcmp(a[i], nalias[j]) == 0) break;
          if(j == na) fprintf(stderr, "alias '%s' not found\n", a[i]);
          else printf("alias %s='%s'\n", nalias[j], valias[j]);
        }
      continue;
    }

    if (!strcmp(a[0],"unalias")) {
      if (nc == 1) {
        fprintf(stderr, "Usage: unalias name [name ...]\n       unalias -a");
        continue;
      }
      if(!strcmp(a[1], "-a")) {
        na = 0;
        continue;
      }
      for(i = 1; i < nc; ++i) {
        for(j = 0; j < na; ++j) if(strcmp(a[i], nalias[j]) == 0) break;
        if(j == na) fprintf(stderr, "alias '%s' not found\n", a[i]);
        else {
          --na;
          for(k = j; k < na; ++k) {
            strcpy(nalias[k], nalias[k + 1]);
            strcpy(valias[k], valias[k + 1]);
          }
        }
      }
      continue;
    }

    if(fork()){
      wait(NULL);
    }else{
      execv(a[0],a);
      perror(a[0]);
      return 1;
    }
  }
  return 0;
}

