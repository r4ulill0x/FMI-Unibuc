#include <stdio.h>
#include <string.h>
int main(int argc, char *argv[]) {
  char *end = "\n"; int start = 1, i;
  if(argc > 1 && !strcmp(argv[1], "-n")) {start = 2; end = "";}
  for(i = start; i < argc - 1; ++i) printf("%s ", argv[i]);
  if(i < argc) printf(argv[i]);
  printf(end);
  return 0;
}

