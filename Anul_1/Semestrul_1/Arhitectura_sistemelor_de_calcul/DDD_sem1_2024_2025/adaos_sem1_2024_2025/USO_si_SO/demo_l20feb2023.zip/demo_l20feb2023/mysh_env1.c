#include<unistd.h>
#include<sys/types.h>
#include<sys/wait.h>
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<ctype.h>

char ldc[256], *a[256], env[256][256],
     nenv[256][265], venv[256][256], *e[256], *p, buf[256];
int na, ne, i, inw;

int main(){
  ne = 0; e[ne] = NULL;
  while(1){
    printf(">>");
    gets(ldc);
    inw = 0; na = 0;
    for(p = ldc; *p; ++p)
      if(!isspace(*p) && !inw) {inw = 1; a[na++] = p;}
      else if(isspace(*p) && inw) {inw = 0; *p = '\0';}
    a[na] = NULL;
    if(na == 0) continue;
    if(!strcmp(a[0],"exit")){
      exit(0);
    }else if(!strcmp(a[0],"export") && na == 2){
      if((p = strchr(a[1], '=')) == NULL) {
        fprintf(stderr, "%s invalid\n", a[1]);
        continue;
      }
      strncpy(buf, a[1], p - a[1]); buf[p - a[1]] = '\0';
      for(i = 0; i < ne; ++i)
        if(!strcmp(nenv[i], buf)) break;
      if(i < ne) {
        strcpy(env[i], a[1]);
        strcpy(venv[i], p+1);
      } else {
        if(ne >= 256){
          fprintf(stderr, "Environment is full\n");
          continue;
        }
        strcpy(env[ne], a[1]);
        strcpy(nenv[ne], buf);
        strcpy(venv[ne], p+1);
        e[ne] = env[ne]; e[++ne] = NULL;
      }
    }else if(!strcmp(a[0],"unset") && na == 2){
      for(i = 0; i < ne; ++i)
        if(!strcmp(nenv[i], a[1])) break;
      if(i >= ne) continue;
      if(i < ne -1) {
        strcpy(env[i], env[ne - 1]);
        strcpy(nenv[i], nenv[ne - 1]);
        strcpy(venv[i], venv[ne - 1]);
      }
      e[--ne] = NULL;
    }else if(fork()){
            wait(NULL);
          }else{
            execvpe(a[0],a,e);
            perror(a[0]);
            return 1;
          }
  }
  return 0;
}

