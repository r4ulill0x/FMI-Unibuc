#include<unistd.h>
#include<sys/types.h>
#include<sys/wait.h>
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<ctype.h>
#include <errno.h>

#define invalid_char(X) (!isalnum(X) && (X) != '_')

char ldc[256], *a[256], env[256][256],
     nenv[256][265], venv[256][256], *e[256], *p, *q, buf[256];
int na, ne, i, stare, ret, rettmp;

int main(){
  ne = 0; e[ne] = NULL;
  rettmp = 0;
  while(1){
    err:
    ret = rettmp;
    rettmp = 0;
    printf(">>");
    gets(ldc);

    for(p = ldc; *p; ++p)
      if(*p == '$') {

        if(p[1]=='?') {
          sprintf(buf,"%d",ret);
          if((p - ldc) + strlen(buf) + strlen(p + 2) >= 256) {
            fprintf(stderr, "Line too long\n");
            goto err;
          }
          bcopy(p + 2, (p + 2) + (strlen(buf) - 2), strlen(p + 2) + 1);
          strncpy(p, buf, strlen(buf));
          continue; /* nu e nevoie --p, deoarece ret are >= 1 cifra */
        }

        for(q = p + 1; ! invalid_char(*q); ++q);
        strncpy(buf, p + 1, q - (p + 1)); buf[q - (p + 1)] = '\0';
        for(i = 0; i < ne; ++i)
          if(!strcmp(nenv[i], buf)) break;
        if(i < ne) strcpy(buf, venv[i]);
        else strcpy(buf, "");
        if((p - ldc) + strlen(buf) + strlen(q) >= 256){
           fprintf(stderr, "Line too long\n");
           goto err;
        }
        bcopy(q, q + (strlen(buf) - (q - p)), strlen(q) + 1);
        strncpy(p, buf, strlen(buf));

        --p;
      }

    na = 0; stare = 0; /* 0 == outw, 1 = inw */
    for(p = ldc; *p; ++p)
      if(!isspace(*p) && !stare) {stare = 1; a[na++] = p;}
      else if(isspace(*p) && stare) {stare = 0; *p = '\0';}
    a[na] = NULL;
    if(na == 0) continue;

    if(!strcmp(a[0],"exit")){
      exit(0);
    }else if(!strcmp(a[0],"export") && na == 2){
      if((p = strchr(a[1], '=')) == NULL) {
        fprintf(stderr, "%s invalid\n", a[1]);
        continue;
      }
      strncpy(buf, a[1], p - a[1]); buf[p - a[1]] = '\0';
      for(i=0; buf[i]; ++i)
        if(invalid_char(buf[i])) {
          fprintf(stderr, "invalid variable name: %s\n", buf);
          continue;
        }
      for(i = 0; i < ne; ++i)
        if(!strcmp(nenv[i], buf)) break;
      if(i < ne) {
        strcpy(env[i], a[1]);
        strcpy(venv[i], p+1);
      } else {
       if(ne >= 256){
          fprintf(stderr, "Environment is full\n");
          continue;
        }
        strcpy(env[ne], a[1]);
        strcpy(nenv[ne], buf);
        strcpy(venv[ne], p+1);
        e[ne] = env[ne]; e[++ne] = NULL;
      }
    }else if(!strcmp(a[0],"unset") && na == 2){
      if(ne == 0) continue;
      for(i = 0; i < ne; ++i)
        if(!strcmp(nenv[i], a[1])) break;
      if(i >= ne) continue;
      if(i < ne -1) {
        strcpy(env[i], env[ne - 1]);
        strcpy(nenv[i], nenv[ne - 1]);
        strcpy(venv[i], venv[ne - 1]);
      }
      e[--ne] = NULL;
    }else if(fork()){
            int wstatus;
            wait(&wstatus);
            if(WIFEXITED(wstatus)) rettmp = WEXITSTATUS(wstatus);
          }else{
            do{
              if(a[0][0] == '/' ||
                 (strlen(a[0]) >=2 && strncmp(a[0], "./", 2) == 0) ||
                 (strlen(a[0]) >=3 && strncmp(a[0], "../", 2) == 0)
              ) {stare = 0; break;}
              for(i = 0; i < ne; ++i)
                if(!strcmp(nenv[i], "PATH")) break;
              if(i == ne) {stare = 1; break;}
              stare = 2; break;
            }while(1);
            switch(stare) {
              case 0: 
              case 1: execve(a[0],a,e); break;
              case 2: p = q = venv[i]; errno = ENAMETOOLONG;
                      do {
                        if(!*q || *q==':') {
                          strncpy(buf, p, q - p); buf[q - p] = '\0';
                          if(strlen(buf) == 0) strcpy(buf, ".");
                          if(buf[strlen(buf) - 1] != '/') strcat(buf, "/");
                          if(strlen(buf) + strlen(a[0]) < 256) {
                            strcat(buf, a[0]); a[0] = buf;
                            execve(buf,a,e);
                          }
                          if(!*q) break;
                          p = q + 1;
                        }
                        ++q;
                      } while(1);
            }
            perror(a[0]);
            return 1;
          }
  }
  return 0;
}

