#include<unistd.h>
#include<sys/types.h>
#include<sys/wait.h>
#include<stdio.h>
#include<string.h>
#include<stdlib.h>

char ldc[256], c0[256], c1[256], *a[256];

int main(){
  while(1){
    printf(">>");
    gets(ldc);
    c0[0]=0; c1[0]=0;
    sscanf(ldc, "%s%s", c0, c1);
    if(!strcmp(c0,"exit")){
      exit(0);
    }else if(!strcmp(c0,"cd") && c1[0] != 0){
      if(chdir(c1) == -1) perror(c1);
    }else if(fork()){
            wait(NULL);
          }else{
            a[0]=c0; a[1]=NULL;
            execv(c0,a);
            perror(c0);
            return 1;
          }
  }
  return 0;
}

