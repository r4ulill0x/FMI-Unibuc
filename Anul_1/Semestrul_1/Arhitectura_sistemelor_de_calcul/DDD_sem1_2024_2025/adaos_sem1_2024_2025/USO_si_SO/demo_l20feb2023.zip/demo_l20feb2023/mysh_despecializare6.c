#include<unistd.h>
#include<sys/types.h>
#include<sys/wait.h>
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<ctype.h>

char ldc[256], relevant[256] /* relevant[i]: -1 = de sters, 0 = nefunctionl, 1 = functional */,
     *a[256], *p, *q;
int nc, i, stare;

int main(){
  while(1){
    printf(">>");
    gets(ldc);

    stare = 0; /* 0 = not ignore; 1 = ignore 1; 2 = ignore  unlimited */
    for(i = 0; ldc[i]; ++i)
      switch(stare) {
        case 0: switch(ldc[i]) {
                  case  '"': stare = 1;
                  case '\\': ++stare;
                             relevant[i] = -1;
                             break;
                  default: relevant[i] = 1;
                }
                break;
        case 1: stare = 0;
                relevant[i] = 0;
                break;
        case 2: switch(ldc[i]) {
                  case '"': stare = 0;
                            relevant[i] = -1;
                            break;
                  case '\\': if(ldc[i+1] == '\"' || ldc[i+1] == '\\') {
                               relevant[i] = -1;
                               ++i;
                               relevant[i] = 0;
                               break;
                             }
                  default:  relevant[i] = 0;
                }
      }
    if(stare != 0) {
      fprintf(stderr, "Unterminated command line\n");
      continue;
    }

    relevant[i] = 1;

    stare = 0; /* 0 = outw; 1 = inw */
    nc = 0;
    for(p = ldc; *p; ++p)
      if((!isspace(*p) || relevant[p - ldc] != 1) && !stare) {stare = 1; a[nc++] = p;}
      else if(isspace(*p) && relevant[p - ldc] == 1 && stare) {stare = 0; *p = '\0';}


    for(i = 0; i < nc; ++i) {
      p = a[i]; q = p;
      do{ 
         if(relevant[q - ldc] != -1) {relevant[p - ldc] = relevant[q - ldc]; *p++ = *q;}
      }while(*q++);
    }

    a[nc] = NULL;
    if(nc == 0) continue;
    if(!strcmp(a[0],"exit")){
      exit(0);
    }else if(fork()){
            wait(NULL);
          }else{
            execv(a[0],a);
            perror(a[0]);
            return 1;
          }
  }
  return 0;
}

